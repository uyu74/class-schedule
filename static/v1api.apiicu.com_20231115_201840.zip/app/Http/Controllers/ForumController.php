<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Crypt;
use Illuminate\Http\Request;
use App\Models\user;
use App\Models\forum;
use App\Models\comment;
class ForumController extends Controller
{
    
    
    //发送帖子
    public function PostForum(){
        $token=request('token');
        $school_id=request('school_id');
        $content=request('content');
        $imgs=request('imgs');
        $forumtype=request('forumtype');
        $id=self::getId($token);

    
    }


    public function getId($token){
        $id = Crypt::decrypt($token);
        $result = explode(',', $id);
        return $result[0];
    }
}
