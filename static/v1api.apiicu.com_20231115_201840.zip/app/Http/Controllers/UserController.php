<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\BaseController;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\JwController;
use App\Http\Controllers\WeChatController;
use App\Models\officedata;
use App\Models\allclasses;
use App\Models\timetable;
use GuzzleHttp\Client;
use App\Models\jwcode;
use App\Models\user;
use App\Models\logerror;
use App\Models\forumtype;
use App\Models\forum;
use App\Models\majia;


class UserController extends Controller
{
  public function __construct()
  {
    $this->middleware('userToken', ['except' => []]);
  }



  public function editTable()
  {
    $token = request('token');
    $table = request('table');
    $id = Crypt::decrypt($token);
    $result = explode(',', $id);
    $user = user::find($result[0]);
    $openid = $user->unionid;
    $tb = timetable::updateOrCreate(['openid' => $openid], [
      'table' => $table
    ]); //改进
    return response()->json(BaseController::Msg(200, 'success', '导入成功'));
  }

  public function ImportByClass()
  {


    $bh_id = request('bh_id');
    $school_id = request('school_id');


    $token = request('token');
    $table = officedata::where("bh", $bh_id)->first()->table;

    $id = Crypt::decrypt($token);
    $result = explode(',', $id);
    $user = user::find($result[0]);
    $openid = $user->unionid;
    $user->school_id = $school_id;
    $user->certification = 1;
    $user->save();
    $tb = timetable::updateOrCreate(['openid' => $openid], [
      'table' => $table
    ]); //改进
    return response()->json(BaseController::Msg(200, 'success', '导入成功'));
  }


  public function import(Request $request)
  {
    $jwu = request('username');
    $jwp = request('password');
    $token = request('token');
    $school_id = request('school_id');
    $id = Crypt::decrypt($token);
    $result = explode(',', $id);
    if ((int)$school_id == 1) {
      //盐城师范获取课表
      // $table = self::getTableF($result[0], $jwu, $jwp);
      $table = self::getTableF2($jwu, $jwp);
      // $table = file_get_contents('http://106.15.227.102/index.php?id=' . $result[0] . '&username=' . $jwu . '&password=' . $jwp);
      $table = json_decode($table, true);
      if (is_array($table) == false) {
        return response()->json(BaseController::Msg(205, 'fail', '请检查账户密码是否正确'));
      }
      if (count($table) != 0) {
        $jwuser = jwcode::where(['user_id' => $result[0]])->get();
        if (count($jwuser) == 0) {
          $jw = new jwcode;
          $jw->user_id = $result[0];
          $jw->user = $jwu;
          $jw->password = Crypt::encrypt($jwp);
          $jw->save();
        } else {
          $ojw = jwcode::where('user_id', $result[0])->first();
          // var_dump($ojw);
          $ojw->user = $jwu;
          $ojw->password = Crypt::encrypt($jwp);
          $ojw->save();
        }
        $user = user::find($result[0]);
        $user->certification = 1;
        $user->school_id = 1;
        $user->save();
        $openid = $user->unionid;
        $tb = timetable::updateOrCreate(['openid' => $openid], [
          'table' => json_encode($table)
        ]); //改进
        return response()->json(BaseController::Msg(200, 'success', '导入成功'));
      }
      if (count($table) == 0) {
        return response()->json(BaseController::Msg(205, 'fail', '请检查账户密码是否正确'));
      }
    }
    if ((int)$school_id == 2) {
      $vccode = request('vccode');
      $table = file_get_contents('http://gxy.wisdomnet.cn/index.php?id=' . $result[0] . '&username=' . $jwu . '&password=' . $jwp . '&vccode=' . $vccode);
      $table = json_decode($table, true);
      if ($table == null) {
        return response()->json(BaseController::Msg(205, 'fail', '请检查账户密码是否正确'));
      }
      if (count($table) != 0) {
        $jwuser = jwcode::where(['user_id' => $result[0]])->get();
        if (count($jwuser) == 0) {
          $jw = new jwcode;
          $jw->user_id = $result[0];
          $jw->user = $jwu;
          $jw->password = Crypt::encrypt($jwp);
          $jw->save();
        } else {
          $ojw = jwcode::where('user_id', $result[0])->first();
          // var_dump($ojw);
          $ojw->user = $jwu;
          $ojw->password = Crypt::encrypt($jwp);
          $ojw->save();
        }
        $user = user::find($result[0]);
        $user->certification = 1;
        $user->school_id = 2;
        $user->save();
        $openid = $user->unionid;
        $tb = timetable::updateOrCreate(['openid' => $openid], [
          'table' => json_encode($table)
        ]);
        return response()->json(BaseController::Msg(200, 'success', '导入成功'));
      }
      if (count($table) == 0) {
        return response()->json(BaseController::Msg(205, 'fail', '请检查账户密码是否正确'));
      }
    }
    if ((int)$school_id == 3) {
      $table = file_get_contents('http://jsyy.apiicu.com/index.php?id=' . $result[0] . '&username=' . $jwu . '&password=' . $jwp);
      $table = json_decode($table, true);
      if (count($table) != 0) {
        $jwuser = jwcode::where(['user_id' => $result[0]])->get();
        if (count($jwuser) == 0) {
          $jw = new jwcode;
          $jw->user_id = $result[0];
          $jw->user = $jwu;
          $jw->password = Crypt::encrypt($jwp);
          $jw->save();
        } else {
          $ojw = jwcode::where('user_id', $result[0])->first();
          $ojw->user = $jwu;
          $ojw->password = Crypt::encrypt($jwp);
          $ojw->save();
        }

        $user = user::find($result[0]);
        $user->certification = 1;
        $user->school_id = 3;
        $user->save();
        $openid = $user->unionid;
        $tb = timetable::updateOrCreate(['openid' => $openid], [
          'table' => json_encode($table)
        ]);
        return response()->json(BaseController::Msg(200, 'success', '导入成功'));
      }
      if (count($table) == 0) {
        return response()->json(BaseController::Msg(205, 'fail', '请检查账户密码是否正确'));
      }
    }
  }



  public function ImportByXH()
  {
    $school_id = request('school_id');
    $xh = request('xh');
    $token = request('token');
    $id = Crypt::decrypt($token);
    $result = explode(',', $id);
    $uid = $result[0];
    $user = user::find($uid);
    $table = allclasses::where('xh', $xh)->get();
    if (count($table) == 0) {
      return response()->json(BaseController::Msg(205, 'fail', '请检查账户是否正确'));
    }
    $utable = allclasses::where('xh', $xh)->first()->table;
    $user->certification = 1;
    $user->school_id = $school_id;
    $user->save();
    $openid = $user->unionid;
    $tb = timetable::updateOrCreate(['openid' => $openid], [
      'table' => $utable
    ]);
    return response()->json(BaseController::Msg(200, 'success', '导入成功'));
  }



  public  function getMillisecond()
  {
    list($msec, $sec) = explode(' ', microtime());
    $msectime =  (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    return $msectimes = substr($msectime, 0, 13);
  }


  public function getTable()
  {
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $user = user::find($id);
    $unionid = $user->unionid;
    $table = timetable::where('openid', $unionid)->get();
    if (count($table) == 0) {
      return response()->json(BaseController::Msg(201, 'fail', '未导入数据！'));
    } else {
      return response()->json(BaseController::Msg(200, 'success', $table[0]->table));
    }
  }

  public function  getVccode()
  {
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $code = file_get_contents('http://gxy.wisdomnet.cn/getvccode.php?id=' . $id);
    return response()->json(BaseController::Msg(200, 'success', $code));
  }

  public function logerror()
  {
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $errors = request('error');
    $logerror = new logerror;
    $logerror->user_id = $id;
    $logerror->logs = $errors;
    $logerror->save();
    return response()->json(BaseController::Msg(200, 'success', ''));
  }

  public function checkPhone()
  {
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $sb = user::find($id);
    if ($sb->phone == null) {
      return response()->json(BaseController::Msg(201, 'fail', 'fuck'));
    } else {
      return response()->json(BaseController::Msg(200, 'success', 'yes'));
    }
  }
  public function getPhone()
  {

    $token = request('token');
    $code = request('code');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $app = WeChatController::init_wx();
    $accessToken = $app->getAccessToken();
    $api = $app->getClient();
    $response = $api->postJson('/wxa/business/getuserphonenumber?access_token=' . $accessToken->getToken(), [
      "code" => $code
    ]);
    $c = $response->getContent();
    $ca = json_decode($c, true);
    // var_dump($ca);
    if ($ca['phone_info']['phoneNumber'] != null) {
      // $uu = user::find($id);
      // $uu->phone = $ca['phone_info']['phoneNumber'];
      // $uu->save();
      return response()->json(BaseController::Msg(200, 'success', $ca['phone_info']['phoneNumber']));
    } else {
      return response()->json(BaseController::Msg(201, 'fail', 'no'));
    }
  }





  public function getForumType()
  {
    $school_id = (int)request('school_id');
    $forumtypes = forumtype::all();
    $result = [];
    foreach ($forumtypes as $type) {
      $res = [];
      $last = forum::where('type_id', $type->id)->latest('created_at')->first();
      $all = forum::where(['type_id' => $type->id, 'school_id' => $school_id])->get();
      if ($last == null) {
        $res['id'] = $type->id;
        $res['name'] = $type->name;
        $res['url'] = $type->url;
        $res['laste'] = null;
        $res['all'] = count($all);
        $result[] = $res;
      } else {
        $res['id'] = $type->id;
        $res['name'] = $type->name;
        $res['url'] = $type->url;
        $res['all'] = count($all);
        $res['laste'] = strtotime($last->created_at);
        $result[] = $res;
      }
    }
    return response()->json(BaseController::Msg(200, 'success', $result));
  }


  public function getMaJia()
  {

    $all = majia::all();
    return response()->json(BaseController::Msg(200, 'success', $all));
  }


  public function PostForum()
  {
    $ip = request()->ip();
    $url = 'http://opendata.baidu.com/api.php?query=' . $ip . '&co=&resource_id=6006&oe=utf8';
    $client = new Client();
    $res = $client->request('GET', $url);
    $res->getStatusCode(); // 获得接口反馈状态码
    $body = $res->getBody(); //获得接口返回的主体对象
    $c = $body->getContents(); //获得主体内容
    $realc = json_decode($c, true);
    // $place=$realc['data'][0]->location;
    $place = $realc['data'][0];
    $fuckp = json_decode(json_encode($place), true)['location'];
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $u = user::find($id);
    $content = request('content');
    $type = request('type');
    $majia_id = request('majia_id');
    $imgs = request('imgs');
    $school_id = request('school_id');
    $forum = new forum;
    $forum->cotents    = $content;
    $forum->type_id    = $type;
    $forum->post_id    = $id;
    $forum->imgs       = $imgs;
    $forum->is_show    = true;
    $forum->majia_id   = $majia_id;
    $forum->city    = $fuckp;
    $forum->school_id    = $school_id;
    $forum->avatar = $u->avatar;
    $forum->nickname = $u->nickname;
    $forum->sex = $u->sex;
    $forum->save();
    return response()->json(BaseController::Msg(200, 'success', $forum));
  }



  public function saveUserInfo()
  {
    $ip = request()->ip();
    $url = 'http://opendata.baidu.com/api.php?query=' . $ip . '&co=&resource_id=6006&oe=utf8';
    $client = new Client();
    $res = $client->request('GET', $url);
    $res->getStatusCode(); // 获得接口反馈状态码
    $body = $res->getBody(); //获得接口返回的主体对象
    $c = $body->getContents(); //获得主体内容
    $realc = json_decode($c, true);
    // $place=$realc['data'][0]->location;
    $place = $realc['data'][0];

    $fuckp = json_decode(json_encode($place), true)['location'];
    $token = request('token');
    $result = Crypt::decrypt($token);
    $id = explode(',', $result)[0];
    $phone = request('phone');
    $avater = request("avater");
    $sex = request("sex");
    $nickname = request("nickname");
    $u = user::find($id);
    $u->city = $fuckp;
    $u->avatar = $avater;
    $u->phone = $phone;
    $u->sex = $sex;
    $u->nickname = $nickname;
    $u->save();
    return response()->json(BaseController::Msg(200, 'success', '信息填写成功！'));
  }


  public function getForum()
  {
    $school_id = request('school_id');
    $id = request('forumtype');
    if ($id == 'all' or $id == null) {
      $f = forum::where('school_id', $school_id)->paginate(5);
      return response()->json(BaseController::Msg(200, 'success', $f));
    } else {
      $f = forum::where(['school_id' => $school_id, 'type_id' => $id])->paginate(5);
      return response()->json(BaseController::Msg(200, 'success', $f));
    }
  }

  public function getInfo()
  {

    $uc = user::all();
    $school_id = request('school_id');
    $f = forum::where('school_id', $school_id)->get();


    $result = [
      'usercount' => count($uc),
      'forumcount' => count($f)
    ];
    return response()->json(BaseController::Msg(200, 'success', $result));
  }




  // session()->put('key2','value2');

  // echo session->get('key2');
  public function getTableF($id, $username, $password)
  {
    // $id = request('id');
    // $username = request('username');
    // $password = request('password');
    $R = rand();
    $cookie_jar = dirname(__FILE__) . "/cookies/" . $R . "pic.cookie";
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://webvpn.ypi.edu.cn/http/webvpn94c3b62f4728745b0b6917f0ad3a17f8/cas/login?service=https://webvpn.ypi.edu.cn/enlink/api/client/callback/cas',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_SSL_VERIFYPEER => FALSE,
      CURLOPT_SSL_VERIFYHOST => FALSE,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_COOKIEJAR => $cookie_jar,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HEADER => array(
        'Host: webvpn.ypi.edu.cn',
        'Connection: close',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'sec-ch-ua: "Chromium";v="21", " Not;A Brand";v="99"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'Referer: https://webvpn.ypi.edu.cn/enlink/sso/login',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: zh-CN,zh;q=0.9'
      )
    ));

    $response01 = curl_exec($curl);
    // <input type="hidden" name="lt" value="LT-1255762-tD2IeQnzRjCnt47azcVNFxPmGpP1xf" />
    preg_match('/<input type="hidden" name="lt" value="(.*?)" \/>/is', $response01, $match);
    $lt = $match[1];
    if (count($match) < 2) {
      unlink($cookie_jar);
      return 1;
    }

    //username=2106090122&password=lFcYxneXT5INyerrE4TqDkzPj8oMFYz4eePq9f8UOb0%3D&lt=LT-1248976-67zshgb6KIy6Ln3ABHpG2aOS3npiyu&execution=e1s1&_eventId=submit&randomStr=
    $post = 'username=' . $username . "&password=" . urlencode(self::encryptF($password, 'c6dda3852e2d4be2')) . '&lt=' . $lt . '&execution=e1s1&_eventId=submit&randomStr=';




    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://webvpn.ypi.edu.cn/http/webvpn94c3b62f4728745b0b6917f0ad3a17f8/cas/login?service=https%3A%2F%2Fwebvpn.ypi.edu.cn%2Fenlink%2Fapi%2Fclient%2Fcallback%2Fcas',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_SSL_VERIFYPEER => FALSE,
      CURLOPT_SSL_VERIFYHOST => FALSE,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_COOKIEFILE => $cookie_jar,
      CURLOPT_COOKIEJAR => $cookie_jar,
      CURLOPT_POSTFIELDS => $post,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_FOLLOWLOCATION => false,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_HEADER => array(
        'Host: webvpn.ypi.edu.cn',
        'Connection: close',
        'Content-Length: 144',
        'Cache-Control: max-age=0',
        'sec-ch-ua: "Chromium";v="21", " Not;A Brand";v="99"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'Upgrade-Insecure-Requests: 1',
        'Origin: https://webvpn.ypi.edu.cn',
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'Referer: https://webvpn.ypi.edu.cn/http/webvpn94c3b62f4728745b0b6917f0ad3a17f8/cas/login?service=https://webvpn.ypi.edu.cn/enlink/api/client/callback/cas',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: zh-CN,zh;q=0.9'
      )
    ));

    $response02 = curl_exec($curl);
    curl_close($curl);
    //location: https://webvpn.ypi.edu.cn/enlink/api/client/callback/cas?ticket=ST-540930-vHz9G4yLzr63Gvt9c4gK-cas
    preg_match('/location: (.*?)(\n)/', $response02, $result1);



    if (count($result1) < 2) {
      unlink($cookie_jar);
      return 3;
    }


    $loacl = trim($result1[1]);
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => $loacl,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_SSL_VERIFYPEER => FALSE,
      CURLOPT_SSL_VERIFYHOST => FALSE,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_COOKIEFILE => $cookie_jar,
      CURLOPT_COOKIEJAR => $cookie_jar,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HEADER => array(
        'Host: webvpn.ypi.edu.cn',
        'Connection: close',
        'Cache-Control: max-age=0',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'sec-ch-ua: "Chromium";v="21", " Not;A Brand";v="99"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'Referer: https://webvpn.ypi.edu.cn/http/webvpn94c3b62f4728745b0b6917f0ad3a17f8/cas/login?service=https://webvpn.ypi.edu.cn/enlink/api/client/callback/cas',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: zh-CN,zh;q=0.9'
      )
    ));

    $response03 = curl_exec($curl);
    curl_close($curl);



    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://webvpn.ypi.edu.cn/http/webvpn38f58c3cff4f62d09d8b38aa0d479ac8/sso/dataTechLogin',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_SSL_VERIFYPEER => FALSE,
      CURLOPT_SSL_VERIFYHOST => FALSE,
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_COOKIEFILE => $cookie_jar,
      CURLOPT_COOKIEJAR => $cookie_jar,
      CURLOPT_TIMEOUT => 10,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HEADER => array(
        'Host: webvpn.ypi.edu.cn',
        'Connection: close',
        'sec-ch-ua: "Chromium";v="21", " Not;A Brand";v="99"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Windows"',
        'Upgrade-Insecure-Requests: 1',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Sec-Fetch-Site: none',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'Accept-Encoding: gzip, deflate',
        'Accept-Language: zh-CN,zh;q=0.9'
      )
    ));

    $response04 = curl_exec($curl);
    curl_close($curl);


    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://webvpn.ypi.edu.cn/http/webvpnd4e3cdacb5c81ff4e0da7b6a1b57d3b2/jwglxt/kbcx/xskbcx_cxXsgrkb.html?gnmkdm=N2151&su=' . $username . '&enlink-vpn',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => FALSE,
      CURLOPT_SSL_VERIFYHOST => FALSE,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => false,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => 'xnm=2023&xqm=3&kzlx=ck&xsdm=',
      CURLOPT_COOKIEFILE => $cookie_jar,
      CURLOPT_COOKIEJAR => $cookie_jar,

    ));

    $response222 = curl_exec($curl);
    curl_close($curl);


    $arryres = json_decode($response222);
    $arraydata = self::object_array($arryres);
    // isset($arraydata['kbList']);
    if (isset($arraydata['kbList'])) {
      $kbdata = $arraydata['kbList'];
    } else {
      return 4;
    }

    // // echo  $response2;
    $kb = json_encode(self::uniqueList2($kbdata), JSON_UNESCAPED_UNICODE);
    // $kb = json_encode(self::uniqueList2($arraydata), JSON_UNESCAPED_UNICODE);
    unlink($cookie_jar);
    return $kb;
    // return $response04;
  }





  function encryptF($string, $key)

  {

    // https://webvpn.ypi.edu.cn/http/webvpn94c3b62f4728745b0b6917f0ad3a17f8/cas/login?service=https://webvpn.ypi.edu.cn/enlink/api/client/callback/cas

    // openssl_encrypt 加密不同Mcrypt，对秘钥长度要求，超出16加密结果不变

    $data = openssl_encrypt($string, 'AES-128-ECB', $key, OPENSSL_RAW_DATA);

    return base64_encode($data);
  }



  function object_array($array)
  {
    if (is_object($array)) {
      $array = (array)$array;
    }
    if (is_array($array)) {
      foreach ($array as $key => $value) {
        $array[$key] = self::object_array($value);
      }
    }
    return $array;
  }
  function uniqueList2($list)
  {
    if (empty($list)) {
      return [];
    }
    $newarr = [];
    foreach ($list as $k => $v) {
      $n =  explode('-', $v['jcs']);
      $newarr[$k]['name']   = $v['kcmc'];
      $newarr[$k]['room']   = $v['cdmc'];
      $newarr[$k]['teacher'] = $v['xm'];
      $newarr[$k]['attend_str'] = $v['zcd'];
      (int)$newarr[$k]['attend']   = self::dealattend($v['zcd']);
      $newarr[$k]['day']   = $v['xqj'];
      $newarr[$k]['nums']    = $n[0];
      $newarr[$k]['enum']    = $n[1];
    }
    return $newarr;
  }

  function dealattend($val1)
  {
    $val1 = str_replace('，', ',', $val1);
    $val1 = str_replace('（', '(', $val1);
    $val1 = str_replace('）', ')', $val1);
    $arry = explode(',', $val1);
    if (strlen($val1) == 4) {
      return  [str_replace('周', '', $val1)];
    } else {
      // var_dump($val1);
      $attend = [];
      foreach ($arry as $key => $a) {
        if (strpos($a, '单') !== false) {
          $res = str_replace('周(单)', '', $a);
          if (strpos($res, '-')) {
            $inall = explode("-", $res);
            $start = $inall[0];
            $end = $inall[1];
            $attend[] = self::pick_one_side(range($start, $end), true);
          } else {
            $attend[] = $a;
          }
          continue;
        }
        if (strpos($a, '双') !== false) {
          $res = str_replace('周(双)', '', $a);
          if (strpos($res, '-')) {
            $inall = explode("-", $res);
            $start = $inall[0];
            $end = $inall[1];
            $attend[] = self::pick_one_side(range($start, $end), false);
          } else {
            $attend[] = $a;
          }
          continue;
        }
        $res = str_replace('周', '', $a);
        if (strpos($res, '-')) {
          $inall = explode("-", $res);
          $start = $inall[0];
          $end = $inall[1];
          $attend[] = range($start, $end);
        } else {
          $attend[] = [(int)$res];
        }
      }
      // var_dump($attend);


      $fres = [];
      foreach ($attend as $k) {
        // var_dump($k);
        foreach ($k as $item) {
          $fres[] = $item;
        }
      }
      return $fres;
    }
  }




  function pick_one_side($arr, $need_odd)
  {
    return array_filter($arr, function ($item) use ($need_odd) {
      return $need_odd ? ($item & 1) : (!($item & 1));
    });
  }

  function dotest1()
  {
    $table = self::getTableF(1, 2106090122, 987654);
    return $table;
  }





  public function getTableF2($username, $password)
  {
    // $username = '2106090122';
    // $password = '987654';
    // $xq=1;
    //获取学期
    //echo 'zheshi'.$username.$password;
    //将获取到的数据转成数组
    //userName=2006090130&password=MEYa5%252BNbKmoPbtwBAXdf3g%253D%253D&wxfwhopenid=null&dllx=H5

    $post = 'userName=' . $username . "&password=" . urlencode(urlencode(self::encryptfun($password, 'qwertyuiqwertyui'))) . '&wxfwhopenid=null&dllx=H5';
    // var_dump($post);
    $curl = curl_init(); //登录获取token
    curl_setopt_array($curl, array(

      CURLOPT_URL => 'http://ydmh.ypi.edu.cn/ydmh/api/user/login',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $post,
    ));
    $response = curl_exec($curl);

    curl_close($curl);
    $content = json_decode($response); //将获取到的数据转成数组
    $content_arr = self::objtoarr($content);
    // var_dump($response);
    $token = array_column($content_arr, 'token'); //通过数组索引token
    //print_r($token);
    $strtoken = implode($token); //转成字符
    //echo $strtoken;
    $shujv = "token: $strtoken"; //token数据
    //echo $shujv;




    //测试
    $token = $shujv;
    $array = array(
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=1&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=2&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=3&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=4&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=5&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=6&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=7&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=8&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=9&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=10&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=11&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=12&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=13&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=14&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=15&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=16&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=17&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",
      "http://ydmh.ypi.edu.cn/ydmh/api/listXskcKcb?zc=18&xq=23-24%E5%AD%A6%E5%B9%B4%E7%AC%AC1%E5%AD%A6%E6%9C%9F&user=null&bjid=null",

    );
    $data = self::Curl_http($array, '10', $token); //调用

    $resData = [];
    if (!empty($data)) {
      foreach ($data as $str) {
        $resData[] = json_decode($str, true);
      }
    }
    $data = $resData;
    // var_dump($data);
    $data = self::uniqueList($data);
    $finaldata = self::transForm($data);
    $finaldatajson = json_encode($finaldata, JSON_UNESCAPED_UNICODE);

    return $finaldatajson;
  }


  public  function Curl_http($array, $timeout, $token)
  {
    $res = array();
    $mh = curl_multi_init(); //创建多个curl语柄
    foreach ($array as $k => $url) {
      $conn[$k] = curl_init($url);
      curl_setopt($conn[$k], CURLOPT_TIMEOUT, $timeout); //设置超时时间
      curl_setopt($conn[$k], CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
      curl_setopt($conn[$k], CURLOPT_MAXREDIRS, 10); //HTTp定向级别
      curl_setopt($conn[$k], CURLOPT_HEADER, 0); //这里不要header，加块效率
      curl_setopt($conn[$k], CURLOPT_FOLLOWLOCATION, 1); // 302 redirect
      curl_setopt($conn[$k], CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($conn[$k], CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
      curl_setopt($conn[$k], CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($conn[$k], CURLOPT_CUSTOMREQUEST, 'GET');
      curl_setopt($conn[$k], CURLOPT_HTTPHEADER, array(
        $token,
      ));

      curl_multi_add_handle($mh, $conn[$k]);
    }

    // 执行批处理句柄
    $active = null;
    do {
      $mrc = curl_multi_exec($mh, $active); //当无数据，active=true
    } while ($mrc == CURLM_CALL_MULTI_PERFORM); //当正在接受数据时
    while ($active && $mrc == CURLM_OK) { //当无数据时或请求暂停时，active=true
      //        if(curl_multi_select($mh) != -1){
      do {
        $mrc = curl_multi_exec($mh, $active);
      } while ($mrc == CURLM_CALL_MULTI_PERFORM);
      //        }
    }


    foreach ($array as $k => $url) {
      curl_error($conn[$k]);
      $res[$k] = curl_multi_getcontent($conn[$k]); //获得返回信息
      $header[$k] = curl_getinfo($conn[$k]); //返回头信息
      curl_close($conn[$k]); //关闭语柄
      curl_multi_remove_handle($mh, $conn[$k]); //释放资源
    }
    curl_multi_close($mh);
    return $res;
  }


  public function uniqueList($list)
  {
    if (empty($list)) {
      return [];
    }
    $list = array_filter($list); //过滤为null或空的子项
    if (!is_array($list[0])) {
      //如果是 [1,1,2,3] 这样的数组，就直接 array_unique
      return array_unique($list);
    }
    if (isset($list[0][0])) {
      if (is_array($list[0]) && is_array($list[0][0])) {
        //对于多个列表合并为一个新列表的情况，扁平化后重新调用这个函数
        $mergedList = [];
        foreach ($list as $subList) {
          $mergedList = array_merge($mergedList, $subList);
        }
        return self::uniqueList($mergedList);
      }
    }
    //取出所有的数组名为一个列表 [zj,jsz,ksjc...]
    $keys = array_keys($list[0]);
    //映射结构，一个小项的值 按顺序 拼接起来作为数组的key,数组的值是 小项
    $res = [];
    foreach ($list as $item) {
      //开始拼接这个值
      $itemKey = '';
      foreach ($keys as $kname) {
        $itemKey .= $item[$kname];
      }
      //这里 $res 为 拼接的key指向 一个小项，如果两个小项一样，第二个会覆盖第一个
      $res[$itemKey] = $item;
    }
    // 把 映射结构 改成列表结构
    return array_values($res);
  }


  public function transForm($srcList)
  {
    $week2Desc = [
      '1' => '周一',
      '2' => '周二',
      '3' => '周三',
      '4' => '周一',
      '5' => '周五',
      '6' => '周六',
      '7' => '周日',
      '0' => '周日'
    ];
    $dstList = [];
    foreach ($srcList as $src) {
      $dst = [];
      $dst['name'] = $src['kcmc'];
      $dst['teacher'] = $src['rkls'];
      $dst['room'] = $src['skjs'];
      $dst['attend_str'] = $week2Desc[$src['zj']] . '第' . $src['ksjc'] . ',' . $src['jsjc'] . '节' . '{第' . $src['ksz'] . '-' . $src['jsz'] . '}周';
      $dst['day'] = $src['zj'];
      $dst["nums"] = (int)$src['ksjc'];
      $dst["enum"] = (int)$src['jsjc'];
      (int)$dst['attend'] = range($src['ksz'], $src['jsz']);
      $dstList[] = $dst;
    }
    return $dstList;
  }



  public function encryptfun($string, $key)

  {

    // openssl_encrypt 加密不同Mcrypt，对秘钥长度要求，超出16加密结果不变

    $data = openssl_encrypt($string, 'AES-128-ECB', $key, OPENSSL_RAW_DATA);

    return base64_encode($data);
  }

  public     function objtoarr($obj)
  {
    $ret = array();
    foreach ($obj as $key => $value) {
      if (gettype($value) == 'array' || gettype($value) == 'object') {
        $ret[$key] = self::objtoarr($value);
      } else {
        $ret[$key] = $value;
      }
    }
    return $ret;
  }
}
