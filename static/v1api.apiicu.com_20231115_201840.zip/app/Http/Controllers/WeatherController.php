<?php

namespace App\Http\Controllers;
use App\Http\Controllers\BaseController;

use Illuminate\Http\Request;

class WeatherController extends Controller
{
    //
    public function getWeather(){
        
    }

}
